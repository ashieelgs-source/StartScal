STARTSCALE COMPLETE WEBSITE

Upload everything in this folder to the ROOT of your GitHub repository.

Pages:
- index.html
- services.html
- shop.html
- contact.html

PDFs:
- AI_Beginner_Toolkit.pdf
- Service_Offer_Starter_Template.pdf
- Client_Request_Checklist.pdf

Payhip Buy Now link:
https://payhip.com/b/1MWWp

Service request email:
ashieelgs@gmail.com

GitHub Pages:
Settings → Pages → Deploy from branch → main → /(root).

If your Payhip URL differs, replace the PAYHIP URL in index.html and shop.html.
